# Testplan Test-PC (Minecraft 1.21.1, NeoForge 21.1.231)

Stand: Quellcode wurde nur geschrieben und statisch geprüft, noch nie kompiliert oder gestartet.
Bitte die Punkte der Reihe nach abhaken. Fehlerausgaben (Gradle oder `logs/latest.log`) an Claude schicken.

## 0. Build
- [ ] Power-Grid-Jar (0.6.2, 1.21.1) nach `libs/powergrid-mc1.21.1-0.6.2.jar` kopieren
- [ ] `./gradlew build` läuft ohne Fehler (erwartete Problemstellen: ModDevGradle-Version, Create/Flywheel-API-Namen, Event-Annotationen)
- [ ] `./gradlew runClient` startet bis ins Hauptmenü, in der Modliste erscheint "Power Grid: High Voltage"
- [ ] Im Log keine Fehler zu `pghv` (fehlende Modelle, Texturen, Registry)

## 1. Creative-Tab und Items
- [ ] Tab "Power Grid: High Voltage" vorhanden, enthält Voltmeter, Kühllüfter, Kabelbox und Kabel
- [ ] Beide Items haben Namen (kein Key-Text), Item-Icons sichtbar (nicht lila-schwarz)

## 2. Hochspannungs-Voltmeter (Messing)
- [ ] Platzieren in allen vier Himmelsrichtungen, Modell ist Messing statt Andesit
- [ ] Anzeigefläche mit Skala sichtbar, Zeiger sichtbar und beweglich
- [ ] Zwei Anschlüsse (rot/blau) lassen sich mit Draht verbinden
- [ ] Bereich per Scroll/Klick umschaltbar: 20 kV, 200 kV, 2 MV
- [ ] Mit Netz von 150 kV: Zeiger steht im Bereich 200 kV nicht am Anschlag
- [ ] Brille (Goggles): Anzeige in kV/MV, kein Absturz
- [ ] Welt speichern/laden: Bereich bleibt erhalten

## 3. Trafo-Kühllüfter (2x2, 1/3 Block dick)
- [ ] Mit dem Lüfter auf eine große Seite des Medium-Trafos klicken (egal welches der vier Felder): Lüfter rastet bündig auf die 2x2-Fläche ein; geht vorne und hinten
- [ ] Freies Platzieren ohne Trafo: vier Teile (2 breit x 2 hoch) erscheinen; bei blockiertem Platz wird nicht platziert
- [ ] Standardposition hinten (Slot 2); Sneak + leere Hand (oder Schraubenschlüssel) schaltet hinten -> vorne -> mittig durch, alle vier Teile wechseln gemeinsam
- [ ] Alle vier Himmelsrichtungen: Modell passt, Teile schließen bündig, Platte ragt in keiner Position aus der Zelle
- [ ] Abbauen eines Teils entfernt die anderen drei, genau ein Item droppt (Kreativmodus: keins)
- [ ] Zwei Pins unten (rot +, blau -) mit Draht verbindbar; 240 V Netz anschließen
- [ ] Rotor dreht sich mit Spannung, steht ohne Spannung; Drehzahl ändert sich ohne Ruckeln
- [ ] Wertebox/Menü: Drehzahl 0..100 % in 5-%-Schritten; weniger Prozent = weniger Leistung (R = 192 Ω / s²)
- [ ] Goggles: Drehzahl, Spannung/Leistung, "Kühlt: Trafo, NN °C" bzw. "Kein Trafo"
- [ ] Am Standard-Medium-Trafo (original Textur) vor/hinter die große Fläche setzen: Temperatur sinkt bei Last schneller als ohne Lüfter; zwei Lüfter (vorne+hinten) kühlen additiv
- [ ] Luftstrom: Spieler/Mobs/Items vor dem Lüfter werden in Blickrichtung weggeblasen, Stärke folgt der Drehzahl; ohne Strom kein Wind
- [ ] Welt speichern/laden: Drehzahl und Position (Slot) bleiben erhalten

## 3b. Erdkabel (Mehrleiter)
- [ ] Rezept: 3 beliebige Drähte (z.B. 2× Kupfer + 1× Eisen) formlos → 2× blankes Kabel; Tooltip zeigt die 3 Adern, Ω/Block und max. A; Item-Litzen in Aderfarben
- [ ] Blankes Kabel lässt sich nicht platzieren
- [ ] Blankes Kabel mittig + 8× getrockneter Seetang ringsum → Erdkabel mit gleichen Adern
- [ ] Rezept Kabelbox (3× Wire Connector, Kupferblech, Kupfergehäuse, Eisenblech) funktioniert, Rezeptbuch zeigt alle drei Rezepte
- [ ] Kabelbox platzieren: Buchse zeigt vom Spieler weg (Schleichen: zum Spieler)
- [ ] Rechtsklick mit Erdkabel auf Box A → Meldung „Kabel begonnen“; Rechtsklick auf Boden setzt Ankerpunkte (auch höher/tiefer); Rechtsklick auf Box B verbindet
- [ ] Segmente liegen sichtbar am Boden, Ecken und Steigungen korrekt verbunden; in festen Blöcken unsichtbar; Boxen drehen die Buchse zum Kabel
- [ ] Verbrauch = Länge in Blöcken (aus Hand + Inventar), Kreativ ohne Verbrauch; zu wenig Kabel → Meldung
- [ ] Anschlusskappen der Boxen in Aderfarben (Kupfer/Eisen/Gold)
- [ ] Je Ader leitet Terminal i von Box A zu Terminal i von Box B (mit Multimeter/Voltmeter prüfen); Widerstand steigt mit Länge, Eisenader höher
- [ ] Goggles an der Box: Adern, Widerstand, Länge, verbunden
- [ ] Welt speichern/laden und weit weggehen (Chunks entladen) → Verbindung danach wieder aktiv
- [ ] Segment abbauen → ganzes Kabel weg, Länge × Erdkabel droppt einmal (kein Dupe, auch bei Explosion)
- [ ] Überlast über Max.-Strom > 2 s → nur diese Ader brennt durch (Rauch), Goggles „Durchgebrannt“

## 4. Texturen und Optik
- [ ] Lüfter-Textur: Stahlgrau mit Messingakzenten, keine Streckung oder verdrehten UVs; Standard-Trafo behält seine Originaltextur
- [ ] Gauge-Skala lesbar
- [ ] Lichtwert des Rotors passt zur Umgebung
